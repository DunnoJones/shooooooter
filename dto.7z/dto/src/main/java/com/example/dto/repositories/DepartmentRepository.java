package com.example.dto.repositories;

import com.example.dto.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Repository;

@Repository
@PreAuthorize("hasRole('ADMIN')")
public interface DepartmentRepository extends JpaRepository<Department, Long> {
    //empty

    @Override
    @PreAuthorize("hasRole('ADMIN')")
    Department getOne(Long aLong);
}
