package com.example.dto.commons;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@ControllerAdvice
@RestController
public class GenericControllerExceptionHandler {

    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public String handleAll(Exception e) {
        return e.getMessage();
    }
}
