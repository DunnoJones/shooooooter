package com.example.dto.repositories;

import com.example.dto.model.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin
@PreAuthorize("hasRole('ROLE_ADMIN')")
public interface UserRoleRepository extends JpaRepository<UserRole, Long> {
    //empty
}
