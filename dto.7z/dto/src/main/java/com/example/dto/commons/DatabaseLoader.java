package com.example.dto.commons;

import com.example.dto.repositories.DepartmentRepository;
import com.example.dto.repositories.UserRepository;
import com.example.dto.repositories.UserRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DatabaseLoader implements CommandLineRunner {

    private final UserRepository userRepository;
    private final UserRoleRepository userRoleRepository;
    private final DepartmentRepository departmentRepository;

    @Autowired
    public DatabaseLoader(UserRepository userRepository, UserRoleRepository userRoleRepository, DepartmentRepository departmentRepository) {
        this.userRepository = userRepository;
        this.userRoleRepository = userRoleRepository;
        this.departmentRepository = departmentRepository;
    }

    @Override
    public void run(String... strings) throws Exception {

//        insert into department (id, name, internal_code) values (1, '111', '111')
//        insert into department (id, name, internal_code) values (2, '222', '222')
//        insert into department (id, name, internal_code) values (3, '333', '333')
//        insert into department (id, name, internal_code) values (4, '444', '4444')
//
//        insert into person (id, username, age, password, phone, department_id) values (1, 'user1', 11, 'pass1', 'phone1', 1)
//        insert into person (id, username, age, password, phone, department_id) values (2, 'user2', 22, 'pass2', 'phone2', 2)
//        insert into person (id, username, age, password, phone, department_id) values (3, 'user3', 33, 'pass3', 'phone3', 1)


/*
        Department department1 = Department.builder().internalCode("intcode1").name("Dep1").build();
        Department department2 = Department.builder().internalCode("intcode2").name("Dep2").build();
        Department department3 = Department.builder().internalCode("intcode3").name("Dep3").build();
        Department department4 = Department.builder().internalCode("intcode4").name("Dep4").build();
        departmentRepository.saveAll(Arrays.asList(department1, department2, department3, department4));


        UserRole userRole1 = new UserRole("ROLE_ADMIN");
        UserRole userRole2 = new UserRole("ROLE_USER");


        Set<User> userSet = new LinkedHashSet<>();
        userSet.add(User.builder().username("Bartek").email("bartek@gmail.com").age(33).password("Bartek").phone("123123123")
                .roles(new HashSet<UserRole>(Arrays.asList(userRole2))).department(department1).build());
        userSet.add(User.builder().username("Jozek").email("jozek@gmail.com").age(66).password("Jozek").phone("999888777")
                .roles(new HashSet<UserRole>(Arrays.asList(userRole2))).department(department2).build());
        userSet.add(User.builder().username("admin").email("admin@gmail.com").age(19).password("admin").phone("+(48) 555091991")
                .roles(new HashSet<UserRole>(Arrays.asList(userRole1))).department(department3).build());

        userRepository.saveAll(userSet);

        //SecurityContextHolder.getContext().setAuthentication(null);
*/
    }
}
