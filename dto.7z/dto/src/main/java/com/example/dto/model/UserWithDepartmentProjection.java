package com.example.dto.model;

import org.springframework.data.rest.core.config.Projection;

@Projection(name = "withDepartment", types = {User.class})
public interface UserWithDepartmentProjection {

    String getUsername();

    Integer getAge();

    Department getDepartment();

}
