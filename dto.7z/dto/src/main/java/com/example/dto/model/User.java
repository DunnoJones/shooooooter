package com.example.dto.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Set;

@Entity
@Data
@ToString(exclude = "password")
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class User {

    public static final PasswordEncoder PASSWORD_ENCODER = new BCryptPasswordEncoder();

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String username;

    @JsonIgnore
    @NotBlank
    private String password;

    @JsonIgnore
    @NotBlank
    @Email
    private String email;

    @JsonIgnore
    private String phone;

    @NotNull
    private Integer age;

    @JsonIgnore
    @ManyToMany(cascade = CascadeType.ALL)
    private Set<UserRole> roles;

    @ManyToOne
    @NotNull
    private Department department;

    public void setPassword(String password) {
        this.password = PASSWORD_ENCODER.encode(password);
    }

    public static class UserBuilder {
        public UserBuilder password(String password) {
            this.password = PASSWORD_ENCODER.encode(password);
            return this;
        }
    }
}
