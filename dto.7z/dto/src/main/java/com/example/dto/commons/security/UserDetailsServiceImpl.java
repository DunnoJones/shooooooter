package com.example.dto.commons.security;

import com.example.dto.model.User;
import com.example.dto.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(s);

        //TODO: add random delay here

        if (user == null) {
            throw new UsernameNotFoundException("User does not exist.");
        } else {
            List<SimpleGrantedAuthority> authorities = new ArrayList<>();

//            for (UserRole userRole : user.getRoles()) {
//                authorities.add(new SimpleGrantedAuthority(userRole.getName()));
//            }
            if (user.getUsername().equals("admin")) {
                authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
            } else {
                authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
            }

            return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), authorities);
        }
    }
}
