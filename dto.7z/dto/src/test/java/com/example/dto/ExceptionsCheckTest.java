package com.example.dto;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ExceptionsCheckTest {

    @Test
    public void go() {
        try
        {
            try {
                throw new Exception("1");
            } catch(Exception e){
                throw new Exception("2");
            } finally {
                throw new Exception("3");
            }
        } catch (Exception eee) {
            System.out.println(eee.getMessage());
        }
    }


}
